import React, { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "../../../icons/icons";

export default function ImageSlider({ images }) {
  const [imageIndex, setImageIndex] = useState(0);
  const imageDivRef = useRef();
  const imageTranslateWidth = imageDivRef?.current?.offsetWidth;
  const imageDivStyle = {
    transform: `translateX(-${imageTranslateWidth * imageIndex}px)`,
  };

  const lastIndex = images.length - 1;

  console.log(imageDivRef);
  const sliderHandler = (direction) => {
    if (direction === "Left") {
      setImageIndex(imageIndex + 1);
    } else {
      setImageIndex(imageIndex - 1);
    }
  };
  console.log(imageIndex);
  return (
    <div className="bg-white w-full h-full relative overflow-hidden">
      <div
        onClick={() => sliderHandler("Left")}
        className={`h-10 w-10 grid items-center justify-center absolute left-3 top-2/4 -translate-y-1/2 z-10 ${
          imageIndex === 0 ? "bg-[#2d2d2d]" : "bg-black"
        } hover:bg-[#2d2d2d] transition cursor-pointer rounded-full`}
      >
        <ChevronLeft />
      </div>
      <div
        ref={imageDivRef}
        style={{
          transform: `translateX(-${imageTranslateWidth * imageIndex}px)`,
        }}
        className={`w-full absolute h-full flex transition-all`}
      >
        {images.map((image, index) => {
          return <img src={image} className="h-full min-w-full" alt="" />;
        })}
        {/* <img src={images[3]} className="h-full w-full" alt="" /> */}
      </div>
      <div
        onClick={() => sliderHandler("Right")}
        className="h-10 w-10 grid items-center justify-center absolute right-3 top-2/4 -translate-y-1/2 z-10 bg-black hover:bg-[#2d2d2d] cursor-pointer transition rounded-full"
      >
        <ChevronRight />
      </div>
    </div>
  );
}
