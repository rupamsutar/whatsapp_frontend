import React from "react";
import MainProjectInfo from "./MainProjectInfo";
import MyYuMeals from "../../Assets/MyYuMeals.jpg";
import GreatQuotes from "../../Assets/GreatQuotes.jpg";
import MyFirstReactApp from "../../Assets/MyFirstReactApp.jpg";
import BeABankist from "../../Assets/BeABankist.jpg";
import Natours from "../../Assets/Natours.jpg";
import { motion } from "framer-motion";
import { fadeIn, textVariant } from "../../utils/motion";
import { styles } from "../../styles";
import {
  firstProject1,
  firstProject2,
  firstProject3,
  firstProject4,
  firstProject5,
} from "../../assets";

const Projects = [
  {
    projectNo: 1,
    projectsImages: [
      firstProject1,
      firstProject2,
      firstProject3,
      firstProject4,
      firstProject5,
    ],
    projectLink: "https://rupamsutar.github.io/MyZomato",
    githubLink: "https://github.com/rupamsutar/MyZomato",
    photoUrl: MyYuMeals,
    title: "MyYuMeals",
    description:
      "Here I've tried to develop a food order app which gets inspired from online food delivery services like Swiggy and Zomato in India. I have tried to use many react concepts like hooks and api context to complete the app. Currently I am trying to add a bit of backend to it !",
    skills: ["React", "React Hooks", "Context-API", "useReducer"],
  },
  {
    projectNo: 2,
    projectsImages: [
      firstProject1,
      firstProject2,
      firstProject3,
      firstProject4,
      firstProject5,
    ],
    projectLink: "https://rupamsutar.github.io/Great-Quotes",
    githubLink: "https://github.com/rupamsutar/Great-Quotes",
    photoUrl: GreatQuotes,
    title: "Great Quotes",
    description:
      "I have developed this application so as to assemble all the great quotes from all of my friend. This is a full stack application where even you can add the quotes of your choice. The data is stored on firebase, Extensive use of React Router has been made to build this product.",
    skills: ["React Router", "React Hooks", "Redux", "Sorting", "Firebase"],
  },
  {
    projectNo: 3,
    projectsImages: [
      firstProject1,
      firstProject2,
      firstProject3,
      firstProject4,
      firstProject5,
    ],
    projectLink: "https://rupamsutar.github.io/beABankist/",
    githubLink: "https://github.com/rupamsutar/beABankist",
    photoUrl: BeABankist,
    title: "Be A Bankist",
    description:
      "There are four users registered on this app. [user: rjs, pin: 1111], [user: pvn, pin: 2222], [user: sbg, pin: 3333], [user: abj, pin: 4444]. Users can transfer Money, take a loan or delete the account. I learnt and gained command over javascript in this project",
    skills: [
      "Javascript",
      "DOM Manipulation",
      "Event Listeners",
      "Local Storage",
    ],
  },
  {
    projectNo: 4,
    projectsImages: [
      firstProject1,
      firstProject2,
      firstProject3,
      firstProject4,
      firstProject5,
    ],
    projectLink: "https://rupamsutar.github.io/My-first-react-app/",
    githubLink: "https://github.com/rupamsutar/My-first-react-app",
    photoUrl: MyFirstReactApp,
    title: "Expense Handler",
    description:
      "This Expense handler might help you in handling your day to day expenses. Developing this app has helped me master my React fundamentals such as props, contextAPI, hooks etc. Building this was one of the best fun I've ever had!",
    skills: ["React", "React-props", "Hooks", "Managing-States"],
  },
  {
    projectNo: 5,
    projectsImages: [
      firstProject1,
      firstProject2,
      firstProject3,
      firstProject4,
      firstProject5,
    ],
    projectLink: "https://rupamsutar.github.io/Natours/",
    githubLink: "https://github.com/rupamsutar/Natours",
    photoUrl: Natours,
    title: "Nature Tourists",
    description:
      "Developing this site, I have used advanced CSS tools such as SASS. I've Tried decorating the site with all the beautiful animations possible. The advanced resposive code makes this site soecial",
    skills: ["Keyframes", "transition", "clip-paths", "Responsive-site"],
  },
];

const MainProject = () => {
  return (
    <>
      <motion.div
        variants={textVariant()}
        className="flex justify-center flex-col items-center"
      >
        <p className={`${styles.sectionSubText} `}>My work</p>
        <h2 className={`${styles.sectionHeadText}`}>Projects.</h2>
      </motion.div>

      <div className="w-full flex mb-24 justify-center">
        <motion.p
          variants={fadeIn("", "", 0.1, 1)}
          className="mt-3 text-secondary text-[17px] max-w-3xl leading-[30px] text-center"
        >
          Following projects showcases my skills and experience through
          real-world examples of my work. Each project is briefly described with
          links to code repositories and live demos in it. It reflects my
          ability to solve complex problems, work with different technologies,
          and manage projects effectively.
        </motion.p>
      </div>
      <div id="work" className="max-w-7xl">
        {Projects.map((project, index) => (
          <MainProjectInfo
            key={project.projectNo}
            {...project}
            index={index}
            totalItems={Projects.length}
            images={project.projectsImages}
          />
        ))}
      </div>
    </>
  );
};

export default MainProject;
